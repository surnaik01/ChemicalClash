//
//  Chemical_ClashApp.swift
//  Chemical-Clash
//
//  Created by Suraga Devraj on 17/02/25.
//

import SwiftUI

@main
struct Chemical_ClashApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
