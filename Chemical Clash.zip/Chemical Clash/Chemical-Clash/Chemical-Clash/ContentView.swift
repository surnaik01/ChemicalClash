//
//  ContentView.swift
//  Chemical-Clash
//
//  Created by Suraga Devraj on 17/02/25.
//

import SwiftUI

struct ContentView: View {
    @State private var showStoryline = false
    @State private var showPractice = false
    @State private var showDifficultySelection = false
    @State private var isMusicPlaying = true
    
    let logoGreen = Color(red: 34/255, green: 177/255, blue: 76/255)
    let backgroundGreen = Color(red: 200/255, green: 236/255, blue: 200/255)
    let accentRed = Color(red: 237/255, green: 85/255, blue: 101/255)
    
    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                ZStack {
                    
                    Image("Background")
                        .resizable()
                        .scaledToFill()
                        .edgesIgnoringSafeArea(.all)
                        .frame(width: geometry.size.width, height: geometry.size.height)
                        .overlay(
                            Color.black.opacity(0.2) //
                        )
                    
                    VStack {
                        // Add a HStack at the top for the music button
                        HStack {
                            Spacer()
                            Button(action: {
                                isMusicPlaying.toggle()
                                toggleBackgroundMusic()
                            }) {
                                Image(systemName: isMusicPlaying ? "speaker.wave.2.fill" : "speaker.slash.fill")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.black.opacity(0.5))
                                    .clipShape(Circle())
                            }
                            .padding(.top, 40)
                            .padding(.trailing, 20)
                        }
                        
                        // Logo image
                        Image("logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: geometry.size.width * 0.6)
                            .padding(.top, 40)
                        
                        // Play button directly beneath logo
                        Button(action: {
                            showDifficultySelection = true
                        }) {
                            Image("play")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 250)
                                .shadow(color: logoGreen.opacity(0.3), radius: 5, x: 0, y: 4)
                        }
                        .padding(.top, 50)
                        
                        Spacer()
                    }
                    
                    
                    VStack {
                        Spacer()
                        HStack {
                            Button(action: {
                                
                                showPractice = true
                            }) {
                                Image("Practice")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 250)
                                    .shadow(color: logoGreen.opacity(0.3), radius: 5, x: 0, y: 4)
                            }
                            .padding(.leading, 18.0)
                            .padding(.bottom, 10.0)
                            
                            Spacer()
                        }
                    }
                }
            }
            .sheet(isPresented: $showDifficultySelection) {
                DifficultySelectionView(showStoryline: $showStoryline)
            }
            .navigationDestination(isPresented: $showStoryline) {
                StorylineView()
            }
            .navigationDestination(isPresented: $showPractice) {
                PracticeView()
            }
            .onAppear {
                toggleBackgroundMusic()
            }
        }
    }
    
    private func toggleBackgroundMusic() {
        if isMusicPlaying {
            MusicPlayer.shared.playBackgroundMusic(backgroundMusicFileName: "puzzle-game-bright-casual-video-game-music-249202", format: "mp3", vol: 0.5)
        } else {
            MusicPlayer.shared.stopBackgroundMusic()
        }
    }
}

struct StorylineView: View {
    @State private var currentScene = 0
    @State private var showGameView = false
    @Environment(\.dismiss) private var dismiss
    let totalScenes = 5
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Scene content
                switch currentScene {
                case 0:
                    SceneView(
                        image: "scene1",
                        text: "Hi,I am Sur and I am a student who loves chemistry",
                        currentScene: $currentScene,
                        totalScenes: totalScenes
                    )
                case 1:
                    SceneView(
                        image: "scene2",
                        text: "I always wonderd how chemicals work at their core",
                        currentScene: $currentScene,
                        totalScenes: totalScenes
                    )
                case 2:
                    SceneView(
                        image: "scene3",
                        text: "So I decided to play a game to know that, while I learn !",
                        currentScene: $currentScene,
                        totalScenes: totalScenes
                    )
                case 3:
                    SceneView(
                        image: "scene4",
                        text: "So lets grab a lab coat and get started",
                        currentScene: $currentScene,
                        totalScenes: totalScenes
                    )
                case 4:
                    SceneView(
                        image: "scene5",
                        text: "Hey I started learning and its so fun,its your turn now go...",
                        currentScene: $currentScene,
                        totalScenes: totalScenes
                    )
                default:
                    EmptyView()
                }
                
              
                VStack {
                    HStack {
                        Spacer()
                        Button(action: {
                            showGameView = true
                        }) {
                            Text("Skip")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundColor(.white)
                                .padding(.horizontal, 20)
                                .padding(.vertical, 10)
                                .background(
                                    Capsule()
                                        .fill(Color.black.opacity(0.5))
                                )
                        }
                        .padding(.top, 50)
                        .padding(.trailing, 20)
                    }
                    Spacer()
                }
            }
        }
        .navigationDestination(isPresented: $showGameView) {
            GameView()
        }
    }
}

struct SceneView: View {
    let image: String
    let text: String
    @Binding var currentScene: Int
    let totalScenes: Int
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
               
                Image(image)
                    .resizable()
                    .scaledToFill()
                    .frame(
                        width: UIScreen.main.bounds.width,
                        height: UIScreen.main.bounds.height
                    )
                    .ignoresSafeArea(.all)
                    .position(
                        x: UIScreen.main.bounds.width/2,
                        y: UIScreen.main.bounds.height/2
                    )
                
        VStack {
                    Spacer()
                    
                    
                    Text(text)
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .frame(width: geometry.size.width * 0.8)
                        .padding()
                        .background(Color.black.opacity(0.3))
                        .cornerRadius(15)
                    
                    // Navigation buttons
                    HStack(spacing: 50) {
                        if currentScene > 0 {
                            Button("Previous") {
                                withAnimation {
                                    currentScene -= 1
                                }
                            }
                            .font(.title3.bold())
                            .foregroundColor(.white)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 15)
                            .background(Color.green.opacity(0.7))
                            .cornerRadius(10)
                        }
                        
                        if currentScene < totalScenes - 1 {
                            Button("Next") {
                                withAnimation {
                                    currentScene += 1
                                }
                            }
                            .font(.title3.bold())
                            .foregroundColor(.white)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 15)
                            .background(Color.green.opacity(0.7))
                            .cornerRadius(10)
                        } else {
                            NavigationLink("Start Game", destination: GameView())
                                .font(.title3.bold())
                                .foregroundColor(.white)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 15)
                                .background(Color.green.opacity(0.7))
                                .cornerRadius(10)
                        }
                    }
                    .padding(.bottom, 50)
                }
            }
            .ignoresSafeArea(.all)
        }
        .ignoresSafeArea(.all)
    }
}

/// <#Description#>
struct GameView: View {
    @State private var currentLevel = 0
    @State private var atoms: [Atom] = []
    @State private var bonds: [Bond] = []
    @State private var draggedAtom: Atom?
    @State private var showSuccess = false
    @State private var showGameComplete = false
    @State private var score = 0
    @State private var attempts = 0
    @State private var showHint = false
    @State private var showError = false
    @State private var errorMessage = ""
    @Environment(\.presentationMode) var presentationMode
    
    
    @State private var scale: CGFloat = 1.0
    @State private var lastScale: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero
    
   
    @State private var showSuccessAnimation = false
    
    
    let difficulty: DifficultySelectionView.Difficulty = {
        if let savedDifficulty = UserDefaults.standard.string(forKey: "gameDifficulty"),
           let difficulty = DifficultySelectionView.Difficulty(rawValue: savedDifficulty) {
            return difficulty
        }
        return .easy
    }()
    
   
    @State private var selectedBondType: BondType = .single
    
    
    var levels: [Level] {
        switch difficulty {
        case .easy:
            return [
                Level(
                    name: "Water (H₂O)",
                    description: "Create water by combining hydrogen and oxygen. Essential for life!",
                    targetMolecule: "H2O",
                    availableAtoms: [
                        Atom(type: .hydrogen, count: 2),
                        Atom(type: .oxygen, count: 1)
                    ]
                ),
                Level(
                    name: "Hydrogen (H₂)",
                    description: "Form a hydrogen molecule - the simplest diatomic molecule",
                    targetMolecule: "H2",
                    availableAtoms: [Atom(type: .hydrogen, count: 2)]
                ),
                Level(
                    name: "Oxygen (O₂)",
                    description: "Create an oxygen molecule with a double bond",
                    targetMolecule: "O2",
                    availableAtoms: [Atom(type: .oxygen, count: 2)]
                ),
                Level(
                    name: "Hydrogen Chloride (HCl)",
                    description: "Make hydrogen chloride - a simple acid molecule",
                    targetMolecule: "HCl",
                    availableAtoms: [
                        Atom(type: .hydrogen, count: 1),
                        Atom(type: .chlorine, count: 1)
                    ]
                ),
                Level(
                    name: "Carbon Monoxide (CO)",
                    description: "Form carbon monoxide with a triple bond",
                    targetMolecule: "CO",
                    availableAtoms: [
                        Atom(type: .carbon, count: 1),
                        Atom(type: .oxygen, count: 1)
                    ]
                )
            ]
            
        case .medium:
            return [
                Level(
                    name: "Carbon Dioxide (CO₂)",
                    description: "Create CO₂ with two double bonds. Key in photosynthesis!",
                    targetMolecule: "CO2",
                    availableAtoms: [
                        Atom(type: .carbon, count: 1),
                        Atom(type: .oxygen, count: 2)
                    ]
                ),
                Level(
                    name: "Ammonia (NH₃)",
                    description: "Build ammonia with its pyramidal shape",
                    targetMolecule: "NH3",
                    availableAtoms: [
                        Atom(type: .nitrogen, count: 1),
                        Atom(type: .hydrogen, count: 3)
                    ]
                ),
                Level(
                    name: "Methane (CH₄)",
                    description: "Form methane - the simplest hydrocarbon",
                    targetMolecule: "CH4",
                    availableAtoms: [
                        Atom(type: .carbon, count: 1),
                        Atom(type: .hydrogen, count: 4)
                    ]
                ),
                Level(
                    name: "Hydrogen Peroxide (H₂O₂)",
                    description: "Create H₂O₂ with its unique O-O bond",
                    targetMolecule: "H2O2",
                    availableAtoms: [
                        Atom(type: .hydrogen, count: 2),
                        Atom(type: .oxygen, count: 2)
                    ]
                ),
                Level(
                    name: "Nitrogen Dioxide (NO₂)",
                    description: "Make NO₂ with its interesting bonding",
                    targetMolecule: "NO2",
                    availableAtoms: [
                        Atom(type: .nitrogen, count: 1),
                        Atom(type: .oxygen, count: 2)
                    ]
                )
            ]
            
        case .hard:
            return [
                Level(
                    name: "Methanol (CH₃OH)",
                    description: "Form methanol with its hydroxyl group (-OH)",
                    targetMolecule: "CH3OH",
                    availableAtoms: [
                        Atom(type: .carbon, count: 1),
                        Atom(type: .hydrogen, count: 4),
                        Atom(type: .oxygen, count: 1)
                    ]
                ),
                Level(
                    name: "Ethanol (C₂H₅OH)",
                    description: "Create ethanol with its hydroxyl group",
                    targetMolecule: "C2H5OH",
                    availableAtoms: [
                        Atom(type: .carbon, count: 2),
                        Atom(type: .hydrogen, count: 6),
                        Atom(type: .oxygen, count: 1)
                    ]
                ),
                Level(
                    name: "Acetylene (C₂H₂)",
                    description: "Build acetylene with its triple bond",
                    targetMolecule: "C2H2",
                    availableAtoms: [
                        Atom(type: .carbon, count: 2),
                        Atom(type: .hydrogen, count: 2)
                    ]
                ),
                Level(
                    name: "Formaldehyde (CH₂O)",
                    description: "Make formaldehyde with its carbonyl group",
                    targetMolecule: "CH2O",
                    availableAtoms: [
                        Atom(type: .carbon, count: 1),
                        Atom(type: .hydrogen, count: 2),
                        Atom(type: .oxygen, count: 1)
                    ]
                ),
                Level(
                    name: "Acetic Acid (CH₃COOH)",
                    description: "Form acetic acid - a challenge molecule!",
                    targetMolecule: "CH3COOH",
                    availableAtoms: [
                        Atom(type: .carbon, count: 2),
                        Atom(type: .hydrogen, count: 4),
                        Atom(type: .oxygen, count: 2)
                    ]
                )
            ]
        }
    }
    
    /// <#Description#>
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Game Background image
                Image("GameBackground")
                    .resizable()
                    .scaledToFill()
                    .edgesIgnoringSafeArea(.all)
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .overlay(
                        Color.black.opacity(0.1)
                    )
                
                VStack(spacing: 15) {
                   
                    HStack {
                        Text("Level: \(currentLevel + 1)/5")
                            .font(.title3.bold())
                        
                        Spacer()
                        
                        Text("Score: \(score)")
                            .font(.title3.bold())
                        
                        Button(action: {
                            resetLevel()
                        }) {
                            Image(systemName: "arrow.counterclockwise")
                                .font(.title2)
                                .foregroundColor(.blue)
                        }
                        .padding(.leading,90)
                    }
                    .padding(.horizontal)
                    
                   
                    VStack(spacing: 8) {
                        Text(levels[currentLevel].name)
                            .font(.system(size: 36, weight: .bold))
                            .foregroundColor(Color(red: 44/255, green: 62/255, blue: 80/255))
                            .padding(.top, 20)
                        
                        Text(levels[currentLevel].description)
                            .font(.title3)
                            .multilineTextAlignment(.center)
                            .foregroundColor(Color(red: 52/255, green: 73/255, blue: 94/255))
                            .padding(.horizontal)
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white.opacity(0.9))
                            .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
                    )
                    .padding(.horizontal)
                    
                    
                    ZStack {
                       
                        RoundedRectangle(cornerRadius: 25)
                            .fill(Color.white)
                            .shadow(color: Color.black.opacity(0.1), radius: 15, x: 0, y: 10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 25)
                                    .stroke(Color.blue.opacity(0.1), lineWidth: 2)
                            )
                        
                       
                        ZStack {
                            // Grid Pattern
                            GeometryReader { geo in
                                Path { path in
                                    let gridSize: CGFloat = 30
                                    for i in stride(from: 0, to: geo.size.width * 2, by: gridSize) {
                                        path.move(to: CGPoint(x: i, y: 0))
                                        path.addLine(to: CGPoint(x: i, y: geo.size.height * 2))
                                    }
                                    for i in stride(from: 0, to: geo.size.height * 2, by: gridSize) {
                                        path.move(to: CGPoint(x: 0, y: i))
                                        path.addLine(to: CGPoint(x: geo.size.width * 2, y: i))
                                    }
                                }
                                .stroke(Color.gray.opacity(0.1), lineWidth: 1)
                            }
                            
                       
                            ForEach(bonds) { bond in
                                BondView(bond: bond)
                            }
                            
                            ForEach(atoms) { atom in
                                AtomView(atom: atom)
                                    .frame(width: 60, height: 60)
                                    .position(atom.position)
                                    .gesture(
                                        DragGesture()
                                            .onChanged { value in
                                                if let index = atoms.firstIndex(where: { $0.id == atom.id }) {
                                                   
                                                    let adjustedLocation = CGPoint(
                                                        x: value.location.x / scale,
                                                        y: value.location.y / scale
                                                    )
                                                    atoms[index].position = adjustedLocation
                                                    checkForBonds()
                                                }
                                            }
                                    )
                            }
                        }
                        .scaleEffect(scale)
                        .offset(offset)
                        .gesture(
                            MagnificationGesture()
                                .onChanged { value in
                                    let delta = value / lastScale
                                    lastScale = value
                                    // Limit zoom range
                                    scale = min(max(scale * delta, 0.5), 3.0)
                                }
                                .onEnded { _ in
                                    lastScale = 1.0
                                }
                        )
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    let delta = CGSize(
                                        width: value.translation.width - lastOffset.width,
                                        height: value.translation.height - lastOffset.height
                                    )
                                    lastOffset = value.translation
                                    offset = CGSize(
                                        width: offset.width + delta.width,
                                        height: offset.height + delta.height
                                    )
                                }
                                .onEnded { _ in
                                    lastOffset = .zero
                                }
                        )
                        .clipped()
                    }
                    .frame(height: geometry.size.height * 0.5)
        .padding()
                    
                    // Add this to the GameView body, after the building area and before the controls
                    HStack(spacing: 20) {
                        Button(action: { selectedBondType = .single }) {
                            VStack {
                                Rectangle()
                                    .frame(width: 60, height: 4)
                                    .foregroundColor(selectedBondType == .single ? .blue : .gray)
                                Text("Single")
                                    .font(.caption)
                                    .foregroundColor(selectedBondType == .single ? .blue : .gray)
                            }
                        }
                        
                        Button(action: { selectedBondType = .double }) {
                            VStack {
                                VStack(spacing: 4) {
                                    Rectangle()
                                        .frame(width: 60, height: 4)
                                    Rectangle()
                                        .frame(width: 60, height: 4)
                                }
                                Text("Double")
                                    .font(.caption)
                            }
                            .foregroundColor(selectedBondType == .double ? .blue : .gray)
                        }
                        
                        Button(action: { selectedBondType = .triple }) {
                            VStack {
                                VStack(spacing: 4) {
                                    Rectangle()
                                        .frame(width: 60, height: 4)
                                    Rectangle()
                                        .frame(width: 60, height: 4)
                                    Rectangle()
                                        .frame(width: 60, height: 4)
                                }
                                Text("Triple")
                                    .font(.caption)
                            }
                            .foregroundColor(selectedBondType == .triple ? .blue : .gray)
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 15)
                            .fill(Color.white)
                            .shadow(color: Color.black.opacity(0.1), radius: 5)
                    )
                    .padding(.horizontal)
                    
                    
                    HStack {
                      
                        
                        Spacer()
                        
                       
                        Button(action: {
                            showHint = true
                        }) {
                            Image(systemName: "lightbulb.fill")
                                .font(.title2)
                                .foregroundColor(.white)
                                .padding(10)
                                .background(Color.yellow.opacity(0.7))
                                .cornerRadius(10)
                        }
                        
                       
                        Button(action: {
                            attempts += 1
                            if validateMolecule() {
                                print("Playing success sound")
                                MusicPlayer.shared.playSoundEffect(soundEffectFileName: "goodresult-82807", format: "mp3", vol: 1.0)
                                score += max(100 - (attempts - 1) * 20, 20)
                                showSuccessAnimation = true
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                    showSuccessAnimation = false
                                    if currentLevel < levels.count - 1 {
                                        currentLevel += 1
                                        resetLevel()
                                    } else {
                                        showGameComplete = true
                                    }
                                }
                            } else {
                                errorMessage = getErrorMessage()
                                showError = true
                            }
                        }) {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                Text("Check Answer")
                            }
                            .font(.title3.bold())
                            .foregroundColor(.white)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 12)
                            .background(Color.green)
                            .cornerRadius(10)
                            .shadow(color: Color.black.opacity(0.2), radius: 3, x: 0, y: 2)
                        }
                        
                        // Add success animation overlay
                        .overlay(
                            ZStack {
                                if showSuccessAnimation {
                                    Color.black.opacity(0.3)
                                        .ignoresSafeArea()
                                    
                                    VStack {
                                        Image(systemName: "checkmark.circle.fill")
                                            .font(.system(size: 60))
                                            .foregroundColor(.green)
                                        
                                        Text("Correct!")
                                            .font(.title.bold())
                                            .foregroundColor(.white)
                                        
                                        Text("+\(max(100 - (attempts - 1) * 20, 20)) points")
                                            .font(.title2)
                                            .foregroundColor(.white)
                                    }
                                    .transition(.scale.combined(with: .opacity))
                                }
                            }
                            .animation(.easeInOut, value: showSuccessAnimation)
                        )
                        
                        Spacer()
                        
                        
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 10)
                    
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(Array(AtomType.allCases), id: \.self) { atomType in
                                VStack(spacing: 2) {
                                    Text("\(atomType.atomicNumber)")
                                        .font(.system(size: 12, weight: .medium))
                                        .foregroundColor(Color(red: 52/255, green: 73/255, blue: 94/255))
                                    
                                    Button(action: {
                                        addAtomToWorkspace(Atom(type: atomType, count: 1))
                                    }) {
                                        AtomView(atom: Atom(type: atomType, count: 1))
                                            .frame(width: 55, height: 55)
                                    }
                                }
                                .padding(5)
                                .background(
                                    RoundedRectangle(cornerRadius: 12)
                                        .fill(Color.white)
                                        .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
                                )
                            }
                        }
                        .padding(.horizontal, 15)
                        .padding(.vertical, 10)
                    }
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white.opacity(0.9))
                            .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: -5)
                    )
                    .frame(height: 120)
                    .padding(.horizontal)
                    .padding(.bottom, 10)
                }
            }
        }
        .alert("Success!", isPresented: $showSuccess) {
            Button("Next Level") {
                if currentLevel < levels.count - 1 {
                    currentLevel += 1
                    resetLevel()
                } else {
                    showGameComplete = true
                }
            }
        } message: {
            Text("You've created the molecule correctly!\nScore: +\(max(100 - (attempts - 1) * 20, 20))")
        }
        .alert("Game Complete!", isPresented: $showGameComplete) {
            Button("Play Again") {
                currentLevel = 0
                score = 0
                resetLevel()
            }
            Button("Main Menu") {
                presentationMode.wrappedValue.dismiss()
            }
        } message: {
            Text("Congratulations! You've completed all levels!\nFinal Score: \(score)")
        }
        .alert("Hint", isPresented: $showHint) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(getLevelHint())
        }
        .alert("Incorrect", isPresented: $showError) {
            Button("Try Again", role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }
    
    private func addAtomToWorkspace(_ atom: Atom) {
        var newAtom = atom
        // Find a non-overlapping position
        let baseX = UIScreen.main.bounds.width/2 - offset.width
        let baseY = UIScreen.main.bounds.height/3 - offset.height
        var position = CGPoint(x: baseX / scale, y: baseY / scale)
        
        // Minimum distance between atoms (slightly larger than atom size)
        let minDistance: CGFloat = 70
        
        // Try different positions if there's overlap
        while isOverlapping(at: position, distance: minDistance) {
            // Move position in a spiral pattern
            position.x += minDistance * cos(CGFloat(atoms.count))
            position.y += minDistance * sin(CGFloat(atoms.count))
        }
        
        newAtom.position = position
        atoms.append(newAtom)
    }
    
    private func isOverlapping(at position: CGPoint, distance: CGFloat) -> Bool {
        for atom in atoms {
            let dx = position.x - atom.position.x
            let dy = position.y - atom.position.y
            let actualDistance = sqrt(dx * dx + dy * dy)
            if actualDistance < distance {
                return true
            }
        }
        return false
    }
    
    private func checkForBonds() {
        bonds = []
        
        for i in 0..<atoms.count {
            for j in (i + 1)..<atoms.count {
                let distance = hypot(
                    atoms[i].position.x - atoms[j].position.x,
                    atoms[i].position.y - atoms[j].position.y
                )
                
                if distance < 120 {
                    let bond = Bond(
                        from: atoms[i].id,
                        to: atoms[j].id,
                        fromPosition: atoms[i].position,
                        toPosition: atoms[j].position,
                        bondType: determineBondType(atoms[i].type, atoms[j].type)
                    )
                    bonds.append(bond)
                }
            }
        }
    }
    
    private func determineBondType(_ atom1: AtomType, _ atom2: AtomType) -> BondType {
        return selectedBondType
    }
    
    private func resetLevel() {
        atoms = []
        bonds = []
        attempts = 0
    }
    
    // Adding validation function for each level
    private func validateMolecule() -> Bool {
        switch difficulty {
        case .easy:
            switch currentLevel {
            case 0: // Water (H₂O)
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                return oxygenCount == 1 && hydrogenCount == 2
                
            case 1: // Hydrogen (H₂)
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                return hydrogenCount == 2
                
            case 2: // Oxygen (O₂)
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return oxygenCount == 2
                
            case 3: // HCl
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                let chlorineCount = atoms.filter { $0.type == .chlorine }.count
                return hydrogenCount == 1 && chlorineCount == 1
                
            case 4: // CO
                let carbonCount = atoms.filter { $0.type == .carbon }.count
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return carbonCount == 1 && oxygenCount == 1
                
            default:
                return false
            }
            
        case .medium:
            switch currentLevel {
            case 0: // CO₂
                let carbonCount = atoms.filter { $0.type == .carbon }.count
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return carbonCount == 1 && oxygenCount == 2
                
            case 1: // NH₃
                let nitrogenCount = atoms.filter { $0.type == .nitrogen }.count
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                return nitrogenCount == 1 && hydrogenCount == 3
                
            case 2: // CH₄
                let carbonCount = atoms.filter { $0.type == .carbon }.count
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                return carbonCount == 1 && hydrogenCount == 4
                
            case 3: // H₂O₂
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return hydrogenCount == 2 && oxygenCount == 2
                
            case 4: // NO₂
                let nitrogenCount = atoms.filter { $0.type == .nitrogen }.count
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return nitrogenCount == 1 && oxygenCount == 2
                
            default:
                return false
            }
            
        case .hard:
            switch currentLevel {
            case 0: // CH₃OH
                let carbonCount = atoms.filter { $0.type == .carbon }.count
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return carbonCount == 1 && hydrogenCount == 4 && oxygenCount == 1
                
            case 1: // C₂H₅OH
                let carbonCount = atoms.filter { $0.type == .carbon }.count
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return carbonCount == 2 && hydrogenCount == 6 && oxygenCount == 1
                
            case 2: // C₂H₂
                let carbonCount = atoms.filter { $0.type == .carbon }.count
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                return carbonCount == 2 && hydrogenCount == 2
                
            case 3: // CH₂O
                let carbonCount = atoms.filter { $0.type == .carbon }.count
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return carbonCount == 1 && hydrogenCount == 2 && oxygenCount == 1
                
            case 4: // CH₃COOH
                let carbonCount = atoms.filter { $0.type == .carbon }.count
                let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
                let oxygenCount = atoms.filter { $0.type == .oxygen }.count
                return carbonCount == 2 && hydrogenCount == 4 && oxygenCount == 2
                
            default:
                return false
            }
        }
    }
    
    private func getLevelHint() -> String {
        switch currentLevel {
        case 0:
            return "Water molecule has one oxygen atom in the center with two hydrogen atoms bonded to it."
        case 1:
            return "CO₂ has a carbon atom in the center with double bonds to two oxygen atoms."
        case 2:
            return "Ammonia has a nitrogen atom bonded to three hydrogen atoms in a pyramidal shape."
        case 3:
            return "Methane has a carbon atom in the center with four hydrogen atoms bonded to it."
        case 4:
            return "Ethanol has two carbon atoms bonded together, with an OH group on one end."
        default:
            return ""
        }
    }
    
    private func getErrorMessage() -> String {
        switch currentLevel {
        case 0:
            return "Check that you have one oxygen atom bonded to two hydrogen atoms."
        case 1:
            return "Make sure you have double bonds between the carbon and oxygen atoms."
        case 2:
            return "Verify that three hydrogen atoms are bonded to the nitrogen atom."
        case 3:
            return "Ensure four hydrogen atoms are bonded to the central carbon atom."
        case 4:
            return "Check the structure: two carbons bonded together, with correct placement of OH group."
        default:
            return "Something's not quite right. Try again!"
        }
    }
}

struct Atom: Identifiable {
    let id = UUID()
    let type: AtomType
    var count: Int
    var position: CGPoint = .zero
}

enum AtomType: String, CaseIterable {
    case hydrogen = "H", helium = "He", lithium = "Li", beryllium = "Be", boron = "B",
         carbon = "C", nitrogen = "N", oxygen = "O", fluorine = "F", neon = "Ne",
         sodium = "Na", magnesium = "Mg", aluminum = "Al", silicon = "Si", phosphorus = "P",
         sulfur = "S", chlorine = "Cl", argon = "Ar", potassium = "K", calcium = "Ca",
         scandium = "Sc", titanium = "Ti", vanadium = "V", chromium = "Cr", manganese = "Mn",
         iron = "Fe", cobalt = "Co", nickel = "Ni", copper = "Cu", zinc = "Zn",
         gallium = "Ga", germanium = "Ge", arsenic = "As", selenium = "Se", bromine = "Br",
         krypton = "Kr", rubidium = "Rb", strontium = "Sr", yttrium = "Y", zirconium = "Zr",
         niobium = "Nb", molybdenum = "Mo", technetium = "Tc", ruthenium = "Ru", rhodium = "Rh",
         palladium = "Pd", silver = "Ag", cadmium = "Cd", indium = "In", tin = "Sn",
         antimony = "Sb", tellurium = "Te", iodine = "I", xenon = "Xe", cesium = "Cs",
         barium = "Ba", lanthanum = "La", cerium = "Ce", praseodymium = "Pr", neodymium = "Nd",
         promethium = "Pm", samarium = "Sm", europium = "Eu", gadolinium = "Gd", terbium = "Tb",
         dysprosium = "Dy", holmium = "Ho", erbium = "Er", thulium = "Tm", ytterbium = "Yb",
         lutetium = "Lu", hafnium = "Hf", tantalum = "Ta", tungsten = "W", rhenium = "Re",
         osmium = "Os", iridium = "Ir", platinum = "Pt", gold = "Au", mercury = "Hg",
         thallium = "Tl", lead = "Pb", bismuth = "Bi", polonium = "Po", astatine = "At",
         radon = "Rn", francium = "Fr", radium = "Ra", actinium = "Ac", thorium = "Th",
         protactinium = "Pa", uranium = "U", neptunium = "Np", plutonium = "Pu", americium = "Am",
         curium = "Cm", berkelium = "Bk", californium = "Cf", einsteinium = "Es", fermium = "Fm",
         mendelevium = "Md", nobelium = "No", lawrencium = "Lr", rutherfordium = "Rf", dubnium = "Db",
         seaborgium = "Sg", bohrium = "Bh", hassium = "Hs", meitnerium = "Mt", darmstadtium = "Ds",
         roentgenium = "Rg", copernicium = "Cn", nihonium = "Nh", flerovium = "Fl", moscovium = "Mc",
         livermorium = "Lv", tennessine = "Ts", oganesson = "Og"
    
    var color: Color {
        switch self {
        case .hydrogen:
            return Color(red: 0.3, green: 0.7, blue: 1.0)
        case .oxygen:
            return Color(red: 1.0, green: 0.3, blue: 0.3)
        case .carbon:
            return Color(red: 0.2, green: 0.2, blue: 0.2)
        case .nitrogen:
            return Color(red: 0.2, green: 0.8, blue: 0.2)
        default:
            // Generate unique colors for other elements
            let hue = Double(AtomType.allCases.firstIndex(of: self)!) / Double(AtomType.allCases.count)
            return Color(hue: hue, saturation: 0.7, brightness: 0.9)
        }
    }
    
    var atomicNumber: Int {
        AtomType.allCases.firstIndex(of: self)! + 1
    }
}

struct Bond: Identifiable {
    let id = UUID()
    let from: UUID
    let to: UUID
    let fromPosition: CGPoint
    let toPosition: CGPoint
    let bondType: BondType
}

enum BondType {
    case single
    case double
    case triple
}

struct Level {
    let name: String
    let description: String
    let targetMolecule: String
    let availableAtoms: [Atom]
}

struct AtomView: View {
    let atom: Atom
    @State private var isAnimating = false
    
    var body: some View {
        ZStack {
            // Outer glow
            Circle()
                .fill(atom.type.color.opacity(0.3))
                .scaleEffect(isAnimating ? 1.2 : 0.8)
                .shadow(color: atom.type.color.opacity(0.3), radius: 10, x: 0, y: 0)
            
            // Main atom circle
            Circle()
                .fill(
                    LinearGradient(
                        gradient: Gradient(colors: [
                            atom.type.color,
                            atom.type.color.opacity(0.8)
                        ]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .overlay(
                    Circle()
                        .stroke(Color.white.opacity(0.5), lineWidth: 2)
                )
                .shadow(color: atom.type.color.opacity(0.3), radius: 5, x: 0, y: 2)
                .rotationEffect(.degrees(isAnimating ? 360 : 0))
            
            // Atom symbol
            Text(atom.type.rawValue)
                .foregroundColor(.white)
                .font(.system(size: 16, weight: .bold))
                .shadow(color: Color.black.opacity(0.3), radius: 2, x: 0, y: 1)
        }
        .onAppear {
            withAnimation(
                Animation
                    .easeInOut(duration: 2)
                    .repeatForever(autoreverses: true)
            ) {
                isAnimating = true
            }
        }
    }
}

struct BondView: View {
    let bond: Bond
    
    var body: some View {
        Group {
            switch bond.bondType {
            case .single:
                singleBond
            case .double:
                doubleBond
            case .triple:
                tripleBond
            }
        }
    }
    
    private var singleBond: some View {
        Path { path in
            path.move(to: bond.fromPosition)
            path.addLine(to: bond.toPosition)
        }
        .stroke(Color.gray, style: StrokeStyle(lineWidth: 3, lineCap: .round))
    }
    
    private var doubleBond: some View {
        Group {
            Path { path in
                path.move(to: offsetPoint(bond.fromPosition, by: -3))
                path.addLine(to: offsetPoint(bond.toPosition, by: -3))
            }
            .stroke(Color.gray, style: StrokeStyle(lineWidth: 2, lineCap: .round))
            
            Path { path in
                path.move(to: offsetPoint(bond.fromPosition, by: 3))
                path.addLine(to: offsetPoint(bond.toPosition, by: 3))
            }
            .stroke(Color.gray, style: StrokeStyle(lineWidth: 2, lineCap: .round))
        }
    }
    
    private var tripleBond: some View {
        Group {
            Path { path in
                path.move(to: bond.fromPosition)
                path.addLine(to: bond.toPosition)
            }
            .stroke(Color.gray, style: StrokeStyle(lineWidth: 2, lineCap: .round))
            
            Path { path in
                path.move(to: offsetPoint(bond.fromPosition, by: -4))
                path.addLine(to: offsetPoint(bond.toPosition, by: -4))
            }
            .stroke(Color.gray, style: StrokeStyle(lineWidth: 2, lineCap: .round))
            
            Path { path in
                path.move(to: offsetPoint(bond.fromPosition, by: 4))
                path.addLine(to: offsetPoint(bond.toPosition, by: 4))
            }
            .stroke(Color.gray, style: StrokeStyle(lineWidth: 2, lineCap: .round))
        }
    }
    
    private func offsetPoint(_ point: CGPoint, by: CGFloat) -> CGPoint {
        let dx = bond.toPosition.x - bond.fromPosition.x
        let dy = bond.toPosition.y - bond.fromPosition.y
        let length = sqrt(dx * dx + dy * dy)
        let unitY = CGPoint(x: -dy / length, y: dx / length)
        return CGPoint(
            x: point.x + unitY.x * by,
            y: point.y + unitY.y * by
        )
    }
}


struct DifficultySelectionView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var showStoryline: Bool
    @State private var selectedDifficulty: Difficulty = .easy
    
    enum Difficulty: String, CaseIterable {
        case easy = "Easy"
        case medium = "Medium"
        case hard = "Hard"
        
        var description: String {
            switch self {
            case .easy:
                return "Perfect for beginners. Simple molecules with clear guidance."
            case .medium:
                return "More complex molecules and challenging combinations."
            case .hard:
                return "Advanced molecules requiring deep chemistry knowledge."
            }
        }
        
        var color: Color {
            switch self {
            case .easy: return .green
            case .medium: return .orange
            case .hard: return .red
            }
        }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.black.opacity(0.9).ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Text("Select Difficulty")
                        .font(.largeTitle.bold())
                        .foregroundColor(.white)
                        .padding(.top, 40)
                    
                    ForEach(Difficulty.allCases, id: \.self) { difficulty in
                        Button(action: {
                            selectedDifficulty = difficulty
                            UserDefaults.standard.set(difficulty.rawValue, forKey: "gameDifficulty")
                            dismiss()
                            showStoryline = true
                        }) {
                            VStack(alignment: .leading, spacing: 10) {
                                Text(difficulty.rawValue)
                                    .font(.title2.bold())
                                    .foregroundColor(.white)
                                
                                Text(difficulty.description)
                                    .font(.body)
                                    .foregroundColor(.white.opacity(0.8))
                                    .multilineTextAlignment(.leading)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding()
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(difficulty.color.opacity(0.3))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 15)
                                            .stroke(difficulty.color, lineWidth: 2)
                                    )
                                )
                        }
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                    
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundColor(.white)
                    .padding(.bottom)
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
