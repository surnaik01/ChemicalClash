import AVFoundation

class MusicPlayer {
    static let shared = MusicPlayer()
    private var audioPlayer: AVAudioPlayer?
    private var soundEffectPlayer: AVAudioPlayer?
    
    func playBackgroundMusic(backgroundMusicFileName: String, format: String, vol: Float) {
        guard let url = Bundle.main.url(forResource: backgroundMusicFileName, withExtension: format) else {
            print("⚠️ Could not find audio file: \(backgroundMusicFileName).\(format)")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.numberOfLoops = -1 // Loop indefinitely
            audioPlayer?.volume = vol
            audioPlayer?.play()
            print("▶️ Playing background music: \(backgroundMusicFileName)")
        } catch {
            print("❌ Error playing background music: \(error.localizedDescription)")
        }
    }
    
    func stopBackgroundMusic() {
        audioPlayer?.stop()
    }
    
    func playSoundEffect(soundEffectFileName: String, format: String, vol: Float) {
        guard let url = Bundle.main.url(forResource: soundEffectFileName, withExtension: format) else {
            print("⚠️ Could not find sound effect: \(soundEffectFileName).\(format)")
            return
        }
        
        do {
            soundEffectPlayer = try AVAudioPlayer(contentsOf: url)
            soundEffectPlayer?.volume = vol
            soundEffectPlayer?.play()
            print("▶️ Playing sound effect: \(soundEffectFileName)")
        } catch {
            print("❌ Error playing sound effect: \(error.localizedDescription)")
        }
    }
} 
