import SwiftUI

struct PracticeView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var currentQuestion = 0
    @State private var atoms: [Atom] = []
    @State private var showHint = false
    @State private var showSuccess = false
    @State private var showError = false
    @State private var errorMessage = ""
    @State private var buildingAreaFrame: CGRect = .zero
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero
    @State private var scale: CGFloat = 1.0
    @State private var lastScale: CGFloat = 1.0
    
    let practiceQuestions = [
        PracticeQuestion(
            name: "Water (H₂O)",
            description: "Let's start with a simple water molecule! Add 2 hydrogen atoms and 1 oxygen atom.",
            instructions: """
            1. Find hydrogen (H) and oxygen (O) atoms in the periodic table below
            2. Tap on them to add them to the workspace
            3. Drag atoms to position them
            4. The bond lines are optional and won't affect your answer
            5. Click 'Check' when you're ready!
            """,
            availableAtoms: [
                Atom(type: .hydrogen, count: 2),
                Atom(type: .oxygen, count: 1)
            ],
            hint: "You need exactly 2 hydrogen atoms and 1 oxygen atom"
        ),
        PracticeQuestion(
            name: "Carbon Dioxide (CO₂)",
            description: "Now try making carbon dioxide! Add 1 carbon atom and 2 oxygen atoms.",
            instructions: """
            1. Find carbon (C) and oxygen (O) atoms below
            2. Tap to add them to the workspace
            3. Position the atoms by dragging them
            4. Bond lines are optional - focus on the right atoms!
            5. Click 'Check' when done
            """,
            availableAtoms: [
                Atom(type: .carbon, count: 1),
                Atom(type: .oxygen, count: 2)
            ],
            hint: "You need 1 carbon atom in the middle and 2 oxygen atoms"
        )
    ]
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Background
                Color.black.opacity(0.9)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 15) {
                    // Header
                    HStack {
                        Button(action: { dismiss() }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.title)
                                .foregroundColor(.white)
                        }
                        .padding()
                        
                        Spacer()
                        
                        Text("Level: 1/2")
                            .font(.title3.bold())
                            .foregroundColor(.white)
                        
                        Spacer()
                        
                        Text("Score: 0")
                            .font(.title3.bold())
                            .foregroundColor(.white)
                            .padding(.trailing)
                    }
                    
                    // Molecule Name and Description
                    Text(practiceQuestions[currentQuestion].name)
                        .font(.title2.bold())
                        .foregroundColor(.white)
                    
                    Text(practiceQuestions[currentQuestion].description)
                        .font(.body)
                        .foregroundColor(.white.opacity(0.8))
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                    
                    // Building Area
                    ZStack {
                        RoundedRectangle(cornerRadius: 15)
                            .fill(Color.white.opacity(0.1))
                            .overlay(
                                GeometryReader { geometry in
                                    Color.clear
                                        .onAppear {
                                            buildingAreaFrame = geometry.frame(in: .global)
                                        }
                                }
                            )
                        
                        // Grid Pattern
                        GeometryReader { geo in
                            Path { path in
                                let gridSize: CGFloat = 30
                                for i in stride(from: 0, to: geo.size.width * 2, by: gridSize) {
                                    path.move(to: CGPoint(x: i, y: 0))
                                    path.addLine(to: CGPoint(x: i, y: geo.size.height * 2))
                                }
                                for i in stride(from: 0, to: geo.size.height * 2, by: gridSize) {
                                    path.move(to: CGPoint(x: 0, y: i))
                                    path.addLine(to: CGPoint(x: geo.size.width * 2, y: i))
                                }
                            }
                            .stroke(Color.white.opacity(0.1), lineWidth: 1)
                        }
                        
                        // Atoms
                        ForEach(atoms) { atom in
                            AtomView(atom: atom)
                                .frame(width: 60, height: 60)
                                .position(atom.position)
                                .gesture(
                                    DragGesture()
                                        .onChanged { value in
                                            if let index = atoms.firstIndex(where: { $0.id == atom.id }) {
                                                atoms[index].position = value.location
                                            }
                                        }
                                )
                        }
                    }
                    .frame(height: geometry.size.height * 0.5)
                    .padding()
                    
                    // Periodic Table Row
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(practiceQuestions[currentQuestion].availableAtoms) { atom in
                                Button(action: {
                                    addAtomToWorkspace(atom)
                                }) {
                                    AtomView(atom: atom)
                                        .frame(width: 60, height: 60)
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    .background(Color.white.opacity(0.1))
                    .frame(height: 80)
                    
                    // Control Buttons
                    HStack(spacing: 20) {
                        Button(action: { showHint = true }) {
                            Text("Hint")
                                .foregroundColor(.white)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 12)
                                .background(Color.blue.opacity(0.6))
                                .cornerRadius(10)
                        }
                        
                        Button(action: { validateMolecule() }) {
                            Text("Check")
                                .foregroundColor(.white)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 12)
                                .background(Color.green.opacity(0.6))
                                .cornerRadius(10)
                        }
                        
                        Button(action: { resetPractice() }) {
                            Text("Reset")
                                .foregroundColor(.white)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 12)
                                .background(Color.red.opacity(0.6))
                                .cornerRadius(10)
                        }
                    }
                    .padding(.bottom)
                }
            }
        }
        .scaleEffect(scale)
        .offset(offset)
        .gesture(
            MagnificationGesture()
                .onChanged { value in
                    let delta = value / lastScale
                    lastScale = value
                    scale = min(max(scale * delta, 0.5), 3.0)
                }
                .onEnded { _ in
                    lastScale = 1.0
                }
        )
        .gesture(
            DragGesture()
                .onChanged { value in
                    let delta = CGSize(
                        width: value.translation.width - lastOffset.width,
                        height: value.translation.height - lastOffset.height
                    )
                    lastOffset = value.translation
                    offset = CGSize(
                        width: offset.width + delta.width,
                        height: offset.height + delta.height
                    )
                }
                .onEnded { _ in
                    lastOffset = .zero
                }
        )
        .alert("Success!", isPresented: $showSuccess) {
            Button("Next") {
                if currentQuestion < practiceQuestions.count - 1 {
                    currentQuestion += 1
                    resetPractice()
                } else {
                    dismiss()
                }
            }
        }
        .alert("Hint", isPresented: $showHint) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(practiceQuestions[currentQuestion].hint)
        }
        .alert("Incorrect", isPresented: $showError) {
            Button("Try Again", role: .cancel) { }
        } message: {
            Text(errorMessage)
        }
    }
    
    private func validateMolecule() {
        switch currentQuestion {
        case 0: // Water
            let oxygenCount = atoms.filter { $0.type == .oxygen }.count
            let hydrogenCount = atoms.filter { $0.type == .hydrogen }.count
            
            if oxygenCount == 1 && hydrogenCount == 2 {
                showSuccess = true
            } else {
                errorMessage = "Make sure you have exactly 2 hydrogen atoms and 1 oxygen atom"
                showError = true
            }
            
        case 1: // CO2
            let carbonCount = atoms.filter { $0.type == .carbon }.count
            let oxygenCount = atoms.filter { $0.type == .oxygen }.count
            
            if carbonCount == 1 && oxygenCount == 2 {
                showSuccess = true
            } else {
                errorMessage = "Make sure you have 1 carbon atom and 2 oxygen atoms"
                showError = true
            }
            
        default:
            break
        }
    }
    
    private func resetPractice() {
        atoms = []
    }
    
    private func addAtomToWorkspace(_ atom: Atom) {
        var newAtom = atom
        
        
        let gridWidth = buildingAreaFrame.width - 120
        let gridHeight = buildingAreaFrame.height - 120
        
        
        let centerX = buildingAreaFrame.minX + (buildingAreaFrame.width / 2)
        let centerY = buildingAreaFrame.minY + (buildingAreaFrame.height / 2)
        
        
        let spacing: CGFloat = min(gridWidth, gridHeight) * 0.25  // Dynamic spacing based on grid size
        let positions: [(x: CGFloat, y: CGFloat)] = [
            (centerX, centerY),
            (centerX + spacing, centerY),         
            (centerX - spacing, centerY),
            (centerX, centerY - spacing),
            (centerX, centerY + spacing),
            (centerX + spacing, centerY + spacing)
        ]
        
        
        let sameTypeCount = atoms.filter { $0.type == atom.type }.count
        
       
        if sameTypeCount < positions.count {
            let position = CGPoint(
                x: positions[sameTypeCount].x,
                y: positions[sameTypeCount].y
            )
            
            
            let finalPosition = CGPoint(
                x: min(max(position.x, buildingAreaFrame.minX + 40), buildingAreaFrame.maxX - 40),
                y: min(max(position.y, buildingAreaFrame.minY + 40), buildingAreaFrame.maxY - 40)
            )
            
            newAtom.position = finalPosition
            atoms.append(newAtom)
        }
    }
}

struct PracticeQuestion {
    let name: String
    let description: String
    let instructions: String
    let availableAtoms: [Atom]
    let hint: String
} 
